#!/bin/bash

cd ~/mjpg-streamer
sudo ./start.sh