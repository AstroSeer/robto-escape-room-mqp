#!/bin/bash
sudo apt-get install python3-flask
cd ~
wget http://osoyoo.com/driver/picar/osoyoowebcar.tar.gz
tar -zxvf osoyoowebcar.tar.gz